function value = hermiteN(n,x)
value = hermite(n,x)/sqrt(factorial(n));
end